# App Menu With Lock Screen

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/mdQvqjp/efa95b4c93cb9ec2081b9238911e7df9](https://codepen.io/Nalini1998/pen/mdQvqjp/efa95b4c93cb9ec2081b9238911e7df9).

A kind of large menu inspired by the Google TV interface. Also has a lock screen component just for funsies.